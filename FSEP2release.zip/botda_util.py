#import h5py
from re import I
#from turtle import Turtle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tkinter as tk
import tkinter.ttk as ttk
from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg, NavigationToolbar2Tk)
import math
import os, sys
##import librosa, librosa.display
import seaborn as sns
from scipy.signal import find_peaks
import datetime
import calendar
from datetime import datetime, timedelta
import clipboard 
import chardet

import pickle
from pathlib import Path

#import shutil
from fpdf import FPDF

from matplotlib import rcParams
rcParams['axes.spines.top'] = False
rcParams['axes.spines.right'] = False


botda_condition = {'max_bfs': 10.85, 
                    'min_bfs': 10.75, 
                    'OpenfileType': 0,      # 0: Omnisens profile txt file, 1: Omnisense Raw txt file, 2: VIAVI raw txt file 
                    'CheckSaveImage': 1,    # 0: Open in display,   2: Save to imagefile
                    'CheckLegend': 0,       # 0: No Legend,         1: Fixed Legend,       2: Flexible Legend
                    'svcanvas': 0,          # 
                    'evcanvas': 0, 
                    'pcanvas': 0, 
                    'mstd_figure': 0,
                    'fiberhomo_figure': 0,  
                    'temp_strain_figure': 0,
                    'drag_marker': 1,       # 0: No Marker,     1: Draggble marker
                    'draw_plot_no': 1,      
                    'ref_fiber_front_index': 0,       # default: 1st fiber 
                    'ref_fiber_rear_index': 0,        # default: 2nd fiber 
                    'file_datetime_format':'%Y_%m_%d_%H_%M_%S',
                    'datetime_format': '%Y-%m-%d %H:%M:%S',
                    'ref_temp_update': 0
                    }


                    
# Corning SMF28+  
fiber_attribute = { 
    'LS_SMF':{
                'Co_Temp' : 1.1,     # (MHz/oC) 0.0011
                'Co_ep' : 0.04916,        # (MHz/ue) 0.4916 #bfs0 = Co_t * T0  + Co_e * e * 1e-4 + 10795
                'Ci_Temp' : 0.33,     # (%/oC) 0.0011
                'Ci_ep' : -0.000807,        # (%/ue) 0.4916 #bfs0 = Co_t * T0  + Co_e * e * 1e-4 + 10.795
                'IndexofRefraction':1.4680
                },
    'Corning_SMF28':{
                'Co_Temp' : 1.096,     # (MHz/oC) 0.0011
                'Co_ep' : 0.04940,        # (MHz/ue) 
                'Ci_Temp' : 0.326,     # (%/oC) 0.0011
                'Ci_ep' : -0.00126,        # (%/ue) 
                'IndexofRefraction':1.4680
                }}


# Popup window
def tabbed_tk_window(self):
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
        import sys
        if sys.version_info[0] < 3:
            import Tkinter as tkinter
            import ttk
        else:
            import tkinter
            from tkinter import ttk
        self.root_window = tkinter.Tk()
        self.root_window.title(self.title)
        # quit if the window is deleted
        self.root_window.protocol("WM_DELETE_WINDOW", self.root_window.quit)
        nb = ttk.Notebook(self.root_window)
        nb.grid(row=1, column=0, sticky='NESW')
        for name, fig in self.figures.items():
            fig.tight_layout()
            tab = ttk.Frame(nb)
            canvas = FigureCanvasTkAgg(self.figures[name], master=tab)
            canvas.draw()
            canvas.get_tk_widget().pack(side=tkinter.TOP, fill=tkinter.BOTH,expand=True)
            toolbar = NavigationToolbar2Tk(canvas, tab)
            toolbar.update()
            canvas._tkcanvas.pack(side=tkinter.TOP, fill=tkinter.BOTH,
                                  expand=True)
            for axes in fig.get_axes():
                if isinstance(axes, Axes3D):
                    # must explicitly allow mouse dragging for 3D plots
                    axes.mouse_init()
            nb.add(tab, text=name)
        nb.pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=True)
        self.root_window.mainloop()
        self.root_window.destroy() 

def directory_search(tartget_directory):
    ## Find the BOTDA txt file in target directory
    ## Return file list

    filelist=[]

    path = tartget_directory    
    entries = os.scandir(path)

    print("Directory:", path)
    for entry in entries:
        
        if '_Freq.txt' in entry.name:
            fullname = path +'/'+ entry.name
            filelist.append(fullname) 
            print("BOTDA data:", entry.name, "\t" , entry.stat().st_size)
        elif '.dtss.txt' in entry.name:
            fullname = path +'/'+ entry.name
            filelist.append(fullname) 
            print("BOTDR data:", entry.name, "\t" , entry.stat().st_size)
        else: 
            print( "Wrong botda file type: ", entry.name, end='\r')
    return filelist           

def GRAPHTEC_Tstring_to_float(x):

#   print("x:", x)   
## Input: + 11.89 as string
## Ouput: 11.89 as float

    x1 = x.split(' ')[-1]
    x0 = str(x.split(' ')[0])
#    print("x0, x1", x0, x1)
    if x0 == '+':
        return float(x1)
    else:
        return -1*float(x1)

def OMRON_Tstring_to_float(x):

#   print("x:", x)   
## Input: +11.89 as string
## Ouput: 11.89 as float

    x1 = x.strip(' ')
#   print("x0, x1", x0, x1)
    return float(x1)


def find_nearest(array,value):
    idx,val = min(enumerate(array), key=lambda x: abs(x[1]-value))
    return idx

def find_nearest_data(array,value):
    array = np.asarray(array)
    idx = (np.abs(array - value)).argmin()
    return idx, array[idx]

def find_nearest_datetime(list_date, base_date):
#    datetime_format='%Y-%m-%d %H:%M:%S'
#    b_d = datetime.strptime(base_date, datetime_format)
    def foo(x):
        return (x-base_date).total_seconds() > 0
    return sorted(list_date, key=foo)[-1]


def find_nearest_datetime2(list_date, base_date):
#    datetime_format='%Y-%m-%d %H:%M:%S'
#    b_d = datetime.strptime(base_date, datetime_format)
    def func(x):
#        d = datetime.strptime(x, datetime_format)
#        print(x)
        d = x
        delta = d - base_date if d > base_date else timedelta.max
        return delta
    return min(list_date, key=func)

# function to test if a file is in unicode
def isItUnicode(filename):
    with open(filename, 'rb') as f:
        encodingInfo = chardet.detect(f.read())
        if "UTF" not in encodingInfo['encoding']: 
            print("This isn't Unicode! It's", encodingInfo['encoding'])
        else: 
            print("Yep, it's Unicode.")
    return encodingInfo['encoding']

def temperature_to_pd(temppath, coding='utf-8', measure_count=1):
    
    # Read temperature file and convert to PANDAS dataframe
    ## Vendor1/Model: "GRAPHTEC Corporation"/"GL840", Vendor2: "OMRON"/"ZR-RX45"
    # Output format: tpara: pandas DataFrame, data: pandas DataFrame

    data = pd.DataFrame()
    datetime_format='%Y/%m/%d %H:%M:%S'
    #tpara, tdata = bu.temperature_to_pd(temppath+"220313-094153.CSV")
    vendor = ''
    para_nrow = 0
    data_skiprows = 0

    encoding_type = isItUnicode(temppath)  ## "askii", 'utf-8'

    vendor_detect = pd.read_csv(temppath, header=None, encoding=encoding_type, index_col = False, engine='python', na_filter=False,  nrows=3)
    vendor_dic = dict(zip(vendor_detect[0], vendor_detect[1]))

    print("vendor detect\n", vendor_dic)
    """
Vendor,"GRAPHTEC Corporation"
Model,"GL840"
Version,"Ver1.61  "

Vendor,"OMRON"
Model,"ZR-RX45"
Version,"Ver1.08  "
    """

    if 'GL' in vendor_dic['Model']:
        para_nrow = 35
        data_skiprows = 36
    elif 'ZR' in vendor_dic['Model']:
        para_nrow = 32
        data_skiprows = 33
    """    
    vendor_detect = pd.read_csv(temppath, header=None, encoding='utf-8',  names=['item', 'value'], index_col = 'item', engine='python', na_filter=False,  nrows=3)
    
    print("vendor detect:\n", vendor_detect)
    print(vendor_detect.loc['Vendor'])

    if vendor_detect.loc['Vendor'] == "GRAPHTEC":
        para_nrow = 39
        data_skiprows = 36
    elif vendor_detect.loc['Vendor'] == 'OMRON':
        para_nrow = 36
        data_skiprows = 33
    """
    encoding_type = 'utf-8'
    # Parameter reading
    tpara = pd.read_csv(temppath, header=None, encoding=encoding_type, index_col = False, engine='python', na_filter=False,  nrows=para_nrow)
    print('tpara shape:', tpara.shape)
#    print(tpara)

    data_col = ['Date&Time'] + ['CH'+ str(i) for i in range(1, measure_count+1)]

    tdata2 = pd.read_csv(temppath, header=0, encoding=encoding_type, index_col = False, engine='python', na_filter=False, skiprows=data_skiprows)
    tdata =  tdata2[data_col].iloc[1:]        

    data['DateTime'] = tdata.apply(lambda x: datetime.strptime(x['Date&Time'], datetime_format), axis=1) # 방법 #1
#   pd.to_datetime(tdata['Date&Time'], format=datetime_format)    
    if 'GL' in vendor_dic['Model']:
        for i in range(1, measure_count+1):
            data['temp'+str(i)] = tdata.apply(lambda x: GRAPHTEC_Tstring_to_float(x['CH'+str(i)]), axis=1) # temp1, temp2, ...
    ###tdata['temp11'] = tdata.apply(lambda x: float(x['CH1'].split(' ')[-1]) if str(x['CH1'].split(' ')[0]) == '+' else -1*float(x['CH1'].split(' ')[-1])), axis=1)
#    data['temp2'] = tdata.apply(lambda x: Tstring_to_float(x['CH2']), axis=1)
    elif 'ZR' in vendor_dic['Model']:
        for i in range(1, measure_count+1):
            data['temp'+str(i)] = tdata.apply(lambda x: OMRON_Tstring_to_float(x['CH'+str(i)]), axis=1) # temp1, temp2, ...

    return tpara, data

def find_stringinfile(path, target):
    print("Find string '{}' in File".format(target))
    # Find the start/end row for parameter and data
    count = 0
    position = 0
    with open(path,'r',encoding='UTF8') as file:
        datafile = file.readlines()
    for line in datafile:
#        print(line)
        count += 1        
        if target in line.split(' '):
            flag = True
            position = count
        else :
            flag = False
            position = None
    return flag, position


def viavi_botdr_to_pd(path, skip_row=None): 
    
    # Read VIAVI BOTDR raw (.txt) file and convert to PANDAS dataframei

    ## Parameter Loading
    coding_type = 'utf-8' # 'utf-8' 'CP949' 'latin'
    vpara = pd.read_csv(path, header=None, encoding=coding_type, names=['item', 'value'], index_col = False, sep='\t', engine='python', na_filter=False, skiprows=1, nrows=58)
    print("vpara shape, columns:", vpara.shape, vpara.columns)
#    print(vpara)
    colno = len(vpara.columns)
#    para_no = pd.read_csv(path, header=None, encoding=coding_type,sep='\t', engine='python', index_col=False, na_filter=False, skiprows=6, nrows=8)
#    colno = len(para_no.columns)-1
#    print("data no:", colno)

    col_para = ['value'+ str(i) for i in range(colno-1)]
    col_para.insert(0, 'item') 

    col_data = ['bfs'+ str(i) for i in range(colno-1)]
    col_data.insert(0, 'dist') 
#    print('col_data:', col_data)

    para, max_count = convert_vpara2opara(vpara)
    para = pd.DataFrame(para, columns=col_para)
    max_row = int(max_count)
#    print("Converted parameter:\n", para)

    result_line = find_stringinfile(path, "[Results]")
    resulttable_line = find_stringinfile(path, "Table Results")
    extendedresult_line = find_stringinfile(path, "[Extended Results]")
    print("Results",result_line, "Table Results",resulttable_line, "Extended Results", extendedresult_line)
    
    if resulttable_line == None:
        skip_row = 67
    skip_row = 68
    ## Data Loading
    vdata = pd.read_csv(path, header=0, encoding='utf-8', index_col = False, sep='\t', engine='python', na_filter=True, skiprows=skip_row, nrows=max_row)
    print("vdata shape", vdata.shape)
    print("vdata columns:", vdata.columns)
#    print(vdata.head(3))
#    print(vdata.tail(3))

    bcolum = vdata.columns.tolist()
    vdata.drop(bcolum[-1], axis=1, inplace=True) 
    vdata.columns = ["dist", "bfs", "BW", "Strain", "Temperature"]
    print("Data shape:", vdata.shape)
    print(vdata.head(3))
    print(vdata.tail(3))

    print("Before fillna:\n", vdata.count())
    vdata.fillna(0, inplace=True)
    print("Before fillna:\n",vdata.count())

    vdata = vdata.astype('float')
#    data = vdata.loc[:, ["dist", "bfs"]]
#    data.columns = col_data
    data = pd.DataFrame(np.array(vdata.loc[:, ["dist", "bfs"]]), columns=col_data)
    print("col_data", col_data)
    print("Data shape:", data.shape)
    print(data.head(3))
    print(data.tail(3))

    return para, data, colno

def convert_opara2opara(bpara):
    # Convert parameter format from VIAVI to Omnisens

#    vpara.set_index(vpara.columns[0], inplace=True)

    para_items = ['Version', 'Type', 'Date', 
            '[Equipment Vendor]', 'Model', 'Serial Number', 
            '[MEASUREMENT]', 'Measurement Date', 'Measurement duration (s)','File Name','Sensor name', 'Sensor ID','Sensor Length (m)',
            'Sample Count','Spatial Resolution (m)','Sampling Interval (ns)','Averaging','Pulse Rate (kHz)',
            'Frequency start (GHz)','Frequency stop (GHz)','Frequency step set (GHz)','Frequency step actual (MHz)',
            'Nb of frequency peak', 'Sensor configuration', 'Frequency scan mode','Probe attenuation (%)','Pulse power factor (%)',
            '[MAINTENANCEINFO]','Internal', 
            '[DATADESCRIPTION]', 'Nb of measurements', 'Distance unit', 'Data type', 'Data unit', 'Measurement Mode']
    para_final_result = []
    para_result = []
    v_dic = {}
    for i, st in enumerate(list(bpara['item'])):
        pa = st.strip(' ')
        bpara['item'].iloc[i] = pa
        if pa == '[DITEST]':
            bpara['item'].iloc[i] = '[Equipment Vendor]'
        elif pa == 'Date' and i == 2:
            bpara['item'].iloc[i] = 'FileDate'
        elif pa == 'Date' and i == 7:
            bpara['item'].iloc[i] = 'Measurement Date'
        elif pa == 'Type' and i == 1:
            bpara['item'].iloc[i] = 'Type'
        elif pa == 'Type' and i == 5:
            bpara['item'].iloc[i] = 'Model'
        else:
            bpara['item'].iloc[i] = pa

#    print(bpara['item'])

    key = list(bpara['item'])
    
    for col in bpara.columns:
        if col == 'item':
            pass
        else:
            val = list(bpara[col])
            kv = [key, val]
            v_dic = dict(zip(*kv))
#            print(v_dic)
            para_result = []
            for para in para_items:
                if para == 'Version':
                    para_result.append([para, v_dic['Version']])
                elif para == 'Type':
                    para_result.append([para, v_dic['Type']])
                elif para == 'Date':
                    para_result.append([para, v_dic['FileDate']])
                elif para == '[Equipment Vendor]':
                    para_result.append([para, 'Omnisens'])
                elif para == 'Model':
                    para_result.append([para, v_dic['Model']])
                elif para == 'Serial Number':
                    para_result.append([para, v_dic['Serial Number']])
                elif para == '[MEASUREMENT]':
                    para_result.append([para, 'BOTDA'])
                elif para == 'Measurement Date':
                    para_result.append([para, v_dic['Measurement Date']])
                elif para == 'Measurement duration (s)':
                    para_result.append([para, v_dic['Measurement duration (s)']])  ## 360s 
                elif para == 'File Name':
                    para_result.append([para, v_dic['File Name']]) 
                elif para == 'Sensor name':
                    para_result.append([para, v_dic['Sensor name']])        
                elif para == 'Sensor ID':
                    para_result.append([para, v_dic['Sensor ID']]) 
                elif para == 'Sensor Length (m)':
                    para_result.append([para, v_dic['Sensor Length (m)']])
                elif para == 'Sample Count':
                    para_result.append([para, v_dic['Sample Count']])
                elif para == 'Spatial Resolution (m)':
                    para_result.append([para, float(v_dic['Spatial Resolution (m)'])])
                elif para == 'Sampling Interval (ns)':
                    para_result.append([para, v_dic['Sampling Interval (ns)']])
                elif para == 'Averaging': 
                    para_result.append([para, v_dic['Averaging']])
                elif para == 'Pulse Rate (kHz)':
                    para_result.append([para, v_dic['Pulse Rate (kHz)']])
                elif para == 'Frequency start (GHz)':
                    para_result.append([para, v_dic['Frequency start (GHz)']])
                elif para == 'Frequency stop (GHz)':
                    para_result.append([para, v_dic['Frequency stop (GHz)']])
                elif para == 'Frequency step set (GHz)':
                    para_result.append([para, v_dic['Frequency step set (GHz)']])
                elif para == 'Frequency step actual (MHz)':
                    para_result.append([para, v_dic['Frequency step actual (MHz)']])
                elif para == 'Nb of frequency peak':
                    para_result.append([para, v_dic['Nb of frequency peak']])
                elif para == 'Sensor configuration':
                    para_result.append([para, v_dic['Sensor configuration']])        
                elif para == 'Frequency scan mode':
                    para_result.append([para, v_dic['Frequency scan mode']])        
                elif para == 'Probe attenuation (%)':
                    para_result.append([para,v_dic['Probe attenuation (%)']])        
                elif para == 'Pulse power factor (%)':
                    para_result.append([para,v_dic['Pulse power factor (%)']])        
                elif para == '[MAINTENANCEINFO]':
                    para_result.append([para,'MAINTENANCEINFO'])        
                elif para == 'Internal':
                    para_result.append([para,'Internal'])      
                elif para == '[DATADESCRIPTION]':
                    para_result.append([para,'BOTDA'])                    
                elif para == 'Nb of measurements':
                    para_result.append([para,v_dic['Nb of measurements']])
                elif para == 'Distance unit':
                    para_result.append([para,v_dic['Distance unit']])
                elif  para ==  'Data type':
                    para_result.append([para,v_dic['Data type']])
                elif para == 'Data unit':
                    para_result.append([para,v_dic['Data unit']])
                elif para == 'Measurement Mode':
                    para_result.append([para,v_dic['Measurement Mode']])
        para_final_result.append([para_result])
    return para_result


def convert_vpara2opara(vpara):
    # Convert parameter format from VIAVI to Omnisens

#    vpara.set_index(vpara.columns[0], inplace=True)

    para_items = ['Version', 'Type', 'Date', 
            '[Equipment Vendor]', 'Model', 'Serial Number', 
            '[MEASUREMENT]', 'Measurement Date', 'Measurement duration (s)','File Name','Sensor name', 'Sensor ID','Sensor Length (m)',
            'Sample Count','Spatial Resolution (m)','Sampling Interval (ns)','Averaging','Pulse Rate (kHz)',
            'Frequency start (GHz)','Frequency stop (GHz)','Frequency step set (GHz)','Frequency step actual (MHz)',
            'Nb of frequency peak', 'Sensor configuration', 'Frequency scan mode','Probe attenuation (%)','Pulse power factor (%)',
            '[MAINTENANCEINFO]','Internal', 
            '[DATADESCRIPTION]', 'Nb of measurements', 'Distance unit', 'Measure Type', 'Data unit', 'Measurement Mode']

    v_dic = {}
    for i, st in enumerate(list(vpara['item'])):
        pa = st.strip(' ')
        vpara['item'].iloc[i] = pa

    key = list(vpara['item'])
    val = list(vpara['value'])
    kv = [key, val]
    v_dic = dict(zip(*kv))
#        print(v_dic)

    para_result = []
    max_count = 0
    for para in para_items:
        if para == 'Version':
            para_result.append([para, v_dic['Txt File Release']])
        elif para == 'Type':
            para_result.append([para, 'Profile'])
        elif para == 'Date':
            rdate = datetime.strptime(v_dic['Date']+' '+v_dic['Time'], '%d/%m/%Y %H:%M:%S')
            para_result.append([para, datetime.strftime(rdate, '%Y-%m-%d %H:%M:%S')])
        elif para == '[Equipment Vendor]':
            para_result.append([para, 'VIAVI solutions'])
        elif para == 'Model':
            para_result.append([para, v_dic['Base Name']+v_dic['Module Name']+v_dic['Software Version']])
        elif para == 'Serial Number':
            para_result.append([para, v_dic['Base SN']+'-'+v_dic['Module SN']])
        elif para == '[MEASUREMENT]':
            para_result.append([para, 'BOTDR'])
        elif para == 'Measurement Date':
            rdate = datetime.strptime(v_dic['Date']+' '+v_dic['Time'], '%d/%m/%Y %H:%M:%S')
            para_result.append([para, datetime.strftime(rdate, '%Y-%m-%d %H:%M:%S')])
        elif para == 'Measurement duration (s)':
            para_result.append([para, 360])  ## 360s 
        elif para == 'File Name':
            para_result.append([para, v_dic['File Name']]) 
        elif para == 'Sensor name':
            para_result.append([para, v_dic['Cable Id Location A']])        
        elif para == 'Sensor ID':
            para_result.append([para, v_dic['Fiber Id Location A']]) 
        elif para == 'Sensor Length (m)':
            para_result.append([para, float(v_dic['Range (km)'])*1000.])
        elif para == 'Sample Count':
            max_count = int(float(v_dic['Range (km)']) *1000. / float(v_dic['Resolution (m)']))
            para_result.append([para, max_count])
        elif para == 'Spatial Resolution (m)':
            para_result.append([para, float(v_dic['Resolution (m)'])])
        elif para == 'Sampling Interval (ns)':
            para_result.append([para, v_dic['Pulse (ns)']])
        elif para == 'Averaging': 
            para_result.append([para, 2000])
        elif para == 'Pulse Rate (kHz)':
            max_count = float(v_dic['Range (km)']) *1000. / float(v_dic['Resolution (m)'])
            para_result.append([para, float(1E6)/(max_count * float(v_dic['Pulse (ns)']))])
        elif para == 'Frequency start (GHz)':
            para_result.append([para, v_dic['Brillouin Freq. Start (GHz)']])
        elif para == 'Frequency stop (GHz)':
            para_result.append([para, v_dic['Brillouin Freq. End (GHz)']])
        elif para == 'Frequency step set (GHz)':
            para_result.append([para, v_dic['Brillouin Freq. Span (MHz)']])
        elif para == 'Frequency step actual (MHz)':
            para_result.append([para, v_dic['Brillouin Freq. Span (MHz)']])
        elif para == 'Nb of frequency peak':
            para_result.append([para, 1])
        elif para == 'Sensor configuration':
            para_result.append([para, 'Reflective: '+ v_dic['Port']+'Port'])        
        elif para == 'Frequency scan mode':
            para_result.append([para, 'Manual'])        
        elif para == 'Probe attenuation (%)':
            para_result.append([para,0])        
        elif para == 'Pulse power factor (%)':
            para_result.append([para,0])        
        elif para == '[MAINTENANCEINFO]':
            para_result.append([para,'MAINTENANCEINFO'])        
        elif para == 'Internal':
            para_result.append([para,'Internal'])      
        elif para == '[DATADESCRIPTION]':
            para_result.append([para,'BOTDR w/ ref temperature '+v_dic['Reference Temperature']])                    
        elif para == 'Nb of measurements':
            para_result.append([para,1])
        elif para == 'Distance unit':
            para_result.append([para,'m'])
        elif para == 'Measure Type':
            para_result.append([para,v_dic['Measure Type']])
        elif para == 'Data unit':
            para_result.append([para,'GHz'])
        elif para == 'Measurement Mode':
            para_result.append([para,'Absolute'])
    return para_result, int(max_count)



def omnisens_botda_to_pd(path): 
    
    # Read Omnisens BOTDA export(.txt) file and convert to PANDAS dataframe

    coding_type = 'utf-8' # 'utf-8' 'CP949' 'latin'
    para_no = pd.read_csv(path, header=None, encoding=coding_type,sep='\t', engine='python', index_col=False, na_filter=False, skiprows=6, nrows=8)
    colno = len(para_no.columns)-1
#    print("data no:", colno)
    print("para shape, columns:", para_no.shape, para_no.columns)

    col_para = ['value'+ str(i) for i in range(colno-1)]
    col_para.insert(0, 'item') 
#    col_para.pop(-1)
#    para.columns = col_para

    col_data = ['bfs'+ str(i) for i in range(colno-1)]
    col_data.insert(0, 'dist') 
#    col_data.pop(-1)
    print('col_para:', col_para, '\t', 'col_data:', col_data)

    # Parameter reading
#    para = pd.read_csv(path, header=None, names=col_para, encoding=coding,sep='\t', engine='python', index_col=False, na_filter=False, skiprows=[0], nrows=40)
    bpara = pd.read_csv(path, header=None, names=col_para, encoding=coding_type,sep='\t', engine='python', index_col=False, na_filter=False, skiprows=1, nrows=40)

    para = convert_opara2opara(bpara)    
    para = pd.DataFrame(para, columns=col_para)

    print(para.head(10))


    # Data reading
    botda = pd.read_csv(path, header=None, names=col_data, encoding=coding_type,sep='\t', engine='python', index_col=False, na_filter=False, skiprows=43)
    print(botda.head(10))
    print(botda.dtypes)
    data = botda.astype('float')
#    data = data.astype('float')

#    n_max = data.shape[0]
#    data['distance'] = pd.DataFrame(np.array(data['dist']))
    data = pd.DataFrame(np.array(data), columns=col_data)

    return para, data, colno

    

"""
#### VIAVI
                              item                        value
0                Txt File Release                           1.0
1                Date                                13/03/2022
2                Time                                  12:44:26
3                File Name          13_03_2022_12_44_26port1001
4                Software Version                         21.54
5                Base Name                            MTS 8000E
6                Base SN                                  10273
7                Module Name                       DFOS-MTS-TS4
8                Module SN                                  100
9          Module Calibration Date                   02/07/2018
10               Status                                 NO TEST
11               Technician Id                            rk03d
12               Comment
13                         [Fiber]                         None
14          Fiber Number                                      1
15          Location A                                container
16          Location B                                     hole
17          Cable Id Location A                       DRC00test
18          Fiber Id Location A                           Fiber
19                         [Setup]                         None
20  Port                                                      1
21  Pulse (ns)                                               20
22  Resolution (m)                                         2.04
23  Range (km)                                         50.00000
24  Brillouin Freq. Start (GHz)                          10.700
25  Brillouin Freq. End (GHz)                            10.900
26  Brillouin Freq. Span (MHz)                                1
27  Number of Frequency                                     201
28  Absolute measurement                                   None
29  Reference Start (km)                                0.19809
30  Reference End (km)                                  0.49829
31  Reference Temperature                                  9.95
32  Number of sections                                        1
33  Section Nb                                                1
34  Section Start (km)                                  0.00500
35  Section End (km)                                   36.00000
36  Fit Type                                              Viavi
37  Fit Level (%)                                           100
38  Measure Type                           Strain & Temperature
39  Ref. Freq. (GHz)                                   10.82110
40  C1 dF T (E)                                         1.09600
41  C2 dF T (E)                                        -0.00002
42  C1 dF E (T)                                         0.04940
43  C2 dF E (T)                                        -0.00001
44  C1 dI T (E)                                         0.32600
45  C2 dI T (E)                                        -0.00000
46  C1 dI E (T)                                        -0.00126
47  C2 dI E (T)                                        -0.00000
******************************

{'Txt File Release': '1.0', 'Date': '13/03/2022', 'Time': '12:44:26', 'File Name
': '13_03_2022_12_44_26port1001', 'Software Version': '21.54', 'Base Name': 'MTS
 8000E', 'Base SN': '10273', 'Module Name': 'DFOS-MTS-TS4', 'Module SN': '100',
'Module Calibration Date': '02/07/2018', 'Status': 'NO TEST', 'Technician Id': '
rk03d', 'Comment': '', '[Fiber]': None, 'Fiber Number': '1', 'Location A': 'cont
ainer', 'Location B': 'hole', 'Cable Id Location A': 'DRC00test', 'Fiber Id Loca
tion A': 'Fiber', '[Setup]': None, 'Port': '1', 'Pulse (ns)': '20', 'Resolution
(m)': '2.04', 'Range (km)': '50.00000', 'Brillouin Freq. Start (GHz)': '10.700',
 'Brillouin Freq. End (GHz)': '10.900', 'Brillouin Freq. Span (MHz)': '1', 'Numb
er of Frequency': '201', 'Absolute measurement': None, 'Reference Start (km)': '
0.19809', 'Reference End (km)': '0.49829', 'Reference Temperature': '9.95', 'Num
ber of sections': '1', 'Section Nb': '1', 'Section Start (km)': '0.00500', 'Sect
ion End (km)': '36.00000', 'Fit Type': 'Viavi', 'Fit Level (%)': '100', 'Measure
 Type': 'Strain & Temperature', 'Ref. Freq. (GHz)': '10.82110', 'C1 dF T (E)': '
1.09600', 'C2 dF T (E)': '-0.00002', 'C1 dF E (T)': '0.04940', 'C2 dF E (T)': '-
0.00001', 'C1 dI T (E)': '0.32600', 'C2 dI T (E)': '-0.00000', 'C1 dI E (T)': '-
0.00126', 'C2 dI E (T)': '-0.00000'}

    
#### Omnisens
0                       Version  ...                            2.0
1                          Type  ...                        Profile
2                          Date  ...            2022-01-19 10:16:50
3                      [DITEST]  ...                           None
4                 Serial Number  ...                       20ST1158
5                          Type  ...                          STA-R
6                 [MEASUREMENT]  ...                           None
7                          Date  ...            2022-01-18 14:33:22
8      Measurement duration (s)  ...                        365.851
9                     File Name  ...        2022_01_18_14_33_22_171
10                  Sensor name  ...  630SQ Ent#7_FO#1_F15_FO#2_F15
11                    Sensor ID  ...                            722
12            Sensor Length (m)  ...                       30000.00
13                 Sample Count  ...                          58769
14       Spatial Resolution (m)  ...                            2.0
15       Sampling Interval (ns)  ...                              5
16                    Averaging  ...                           2000
17             Pulse Rate (kHz)  ...                      1.7015873
18        Frequency start (GHz)  ...                          10.68
19         Frequency stop (GHz)  ...               10.9399999999999
20     Frequency step set (GHz)  ...                          0.001
21  Frequency step actual (MHz)  ...                            1.0
22         Nb of frequency peak  ...                              1
23         Sensor configuration  ...                           Loop
24          Frequency scan mode  ...                         Manual
25        Probe attenuation (%)  ...                              0
26       Pulse power factor (%)  ...                              0
27            [MAINTENANCEINFO]  ...                           None
28                     Internal  ...                               
29            [DATADESCRIPTION]  ...                           None
30           Nb of measurements  ...                              1
31                Distance unit  ...                              m
32                    Data type  ...            Brillouin Frequency
33                    Data unit  ...                            GHz
34             Measurement Mode  ...                       Absolute
35          data_structure_type  ...                              2
36                     f1_start  ...                              2
37                       f1_end  ...                          28151
38                     f2_start  ...                          28152
39                       f2_end  ...                          56301
40                     ev_start  ...                          55714
41                       ev_end  ...                          56301
"""



def bfs_to_rebfs(ab_bfs):

    T0 = 0.0 # oC
    e = 0.0  # ue
    Co_t = 0.0011 # (GHz/oC)
    Co_e = 0.4916 # (GHz/%)
    bfs0 = Co_t * T0  + Co_e * e * 1e-4 + 10.795

    rebfs = (ab_bfs - bfs0)

    return rebfs

def bfs_to_strain(ab_bfs, To=20):

    T0 = 0.0 # oC
    e = 0.0  # ue
    Co_t = 0.0011 # (GHz/oC)
    Co_e = 0.4916 # (GHz/%)
    bfs0 = Co_t * T0  + Co_e * e * 1e-4 + 10.795
    
    strain = ( float(ab_bfs) - bfs0 - Co_t * To) / Co_e * 1e4 
    
    return strain


def frequency_sepectrum(x, sf, time_window = 0, zero_crossing=True):
    """
    Derive frequency spectrum of a signal from time domain
    :param x: signal in the time domain
    :param sf: sampling frequency
    :returns frequencies and their content distribution
    """
    window = 1
    if zero_crossing == True:
        x = x - np.average(x)  # zero-centering
    else:
        pass

    n = len(x)
    print("FFT with Sampling frequency:{}, max_count:{}".format(sf, n))

    if time_window == 0:
        window = 1
    elif time_window == 1 or time_window == "hammming":
        window = np.hamming(n)
    elif time_window == 2 or time_window == "blackman":
        window = np.blackman(n)

    k = np.arange(n)
    tarr = n / float(sf)      # time window
    frqarr = k / float(tarr)  # two sides frequency range

    frqarr = frqarr[np.arange(n // 2)]  # one side frequency range

    x = np.fft.fft(window * x) / n  # fft computing and normalization
    x = x[np.arange(n // 2)]

    return frqarr, 20*np.log10(abs(x))


def botda_multiplot(botda_data, botda_para, start_index = 0, end_index=0):
    # Multiple BOTDA data plot

    fig = plt.figure(figsize=(20,20))

    colno = len(botda_data.columns)
    print("Plot: \n colno:", colno)
    print(botda_data.columns)
#   col_data = ['bfs'+ str(i) for i in range(colno-1)]
#   col_data.insert(0, 'dist') 

    for col_index in range(colno):
        if col_index == 0:
            pass
        else:
            sensorname = botda_para.iloc[10, col_index]
            filename = botda_para.iloc[9, col_index]
            print(botda_para)
            print(sensorname, filename)
            print(botda_data.columns[col_index])
            end_index = len(botda_data.iloc[:,col_index])
            print('start_index:{}, end_index: {}'.format(start_index, end_index))  
            fiberno = 'bfs'+str(col_index-1)
            plt.plot(botda_data['dist'].iloc[start_index:end_index], botda_data[fiberno].iloc[start_index:end_index], 'b', label=sensorname)
        #fig = plt.plot(botda_data.index[n_low:n_high], botda_data[fiberno].iloc[n_low:n_high], 'b', label=fiberno)
    
    plt.grid()
    plt.title("BOTDA plot")
    plt.xlabel('Distance (km)')
    plt.ylabel('BFS (GHz)')
    plt.legend(loc=0)
    #plt.axis([-10,50,10.70,10.9]) # Initial n_low = 1
    plt.show()

     
#    plt.savefig('/mnt/DataS/BOTDA_data/202012_Orsted_CHW/image/LOT#F_start_end.jpg', dpi=300)

def botda_singleplot(b_data, sensorname='test', start_index=0, end_index=0, color = 'b'):
    # Multiple BOTDA data plot

    fig = plt.figure(figsize=(20,20))

    start_index =0
    end_index = len(b_data)
    fiberno = 'bfs0'
    print('start_index:{}, end_index: {}'.format(start_index, end_index))  
    plt.plot(b_data['dist'].iloc[start_index:end_index], b_data[fiberno].iloc[start_index:end_index], color, label=sensorname)
    #fig = plt.plot(botda_data.index[n_low:n_high], botda_data[fiberno].iloc[n_low:n_high], 'b'r, label=fiberno)
    
    plt.grid()
    plt.title("BFS plot: "+sensorname)
    plt.xlabel('Distance (km)')
    plt.ylabel('BFS (GHz)')
    #plt.legend(loc=0)
    #plt.axis([-10,50,10.70,10.9]) # Initial n_low = 1
    plt.show()

def find_start_end(data, max_bfs=10.85, min_bfs=10.75, max_distance_index=None, min_distance_index=0):
    # Remove the data out of range. 

    if max_distance_index == None:
        n_data = len(data)
    else:
        n_data = max_distance_index
    print("Max Data No, Max Distance Index():", len(data), n_data)



    sv_start = min_distance_index
    sv_end = int(n_data * 0.01)

    ev_start = int(n_data * 0.5)
    ev_end = ev_start

#    n_interval = int(n_data * 0.2) 
        
    df1 = data.iloc[0:sv_end]
    bfs_low25 = df1.describe().loc['25%']
#    bfs_high = df1.describe().loc['75%']

#    df2 = data[colname[1]].iloc[ev_start:ev_end]
#    bfs_high = df2.describe().loc['75%']

    # Find the start point
    for bfs in df1:
        if float(bfs) < min(min_bfs, bfs_low25):
            sv_start += 1
#    sv_start +=1

    df2 = data.iloc[int(n_data *0.5)+10:int(n_data *0.95)]
    bfs_low = round(df2.describe().loc['min']-df2.describe().loc['std']*20,3)
    bfs_high = round(df2.describe().loc['max']+df2.describe().loc['std']*20,3)

    print('bfs_low25:',bfs_low25,'bfs_low:', bfs_low, 'min_bfs:', min_bfs, 'bfs_high:', bfs_high, 'max_bfs:', max_bfs)
    
    # Find the end point
    df3 = data.iloc[ev_start:n_data]
    fiber_end = ev_start
    count = 0

    for bfs in df3:
        if bfs < max_bfs and bfs > min_bfs:
            ev_end += 1
        else:
            count += 1
#            print(count, end='r')
            if count == 3:
                fiber_end = ev_end
#                print("fiberend:", fiber_end)
                break

#            peak_index, _ = find_peaks(df2.iloc[ev_start, ev_end], prominence=20) #, distance = 1000)            
            
#            data[colname[1]].iloc[ev_start] = min_bfs 
#    df3 = data1['bfs0'].iloc[ev_end-n_interval:ev_end]

#    ev_end = ev_start  
    ev_start = ev_end - int(int(n_data * 0.01)) 

    ## Validation 
    print("Check nominal data (sv_start+10:int(n_data *0.6) vs (fiber_start:fiber_end) :")
    df3 = data.iloc[sv_start:ev_end]
    print(df2.describe(), df3.describe())

    return sv_start, sv_end, ev_start, ev_end, fiber_end


def find_start_end_v1(data, max_bfs=10.85, min_bfs=10.75):
    # Remove the data out of range. 

    n_data = len(data)
    print("data no:", n_data)

    sv_start = 0
    sv_end = int(n_data * 0.01)

    ev_start = int(n_data * 0.5)
    ev_end = ev_start

#    n_interval = int(n_data * 0.2) 
        
    df1 = data.iloc[0:sv_end]
    bfs_low25 = df1.describe().loc['25%']
#    bfs_high = df1.describe().loc['75%']

#    df2 = data[colname[1]].iloc[ev_start:ev_end]
#    bfs_high = df2.describe().loc['75%']

    # Find the start point
    for bfs in df1:
        if float(bfs) < min(min_bfs, bfs_low25):
            sv_start += 1
#    sv_start +=1

    df2 = data.iloc[int(n_data *0.55)+10:int(n_data *0.6)]
    bfs_low = round(df2.describe().loc['min']-df2.describe().loc['std']*20,3)
    bfs_high = round(df2.describe().loc['max']+df2.describe().loc['std']*20,3)

    print('bfs_low25:',bfs_low25,'bfs_low:', bfs_low, 'min_bfs:', min_bfs, 'bfs_high:', bfs_high, 'max_bfs:', max_bfs)
    
    # Find the end point
    df3 = data.iloc[ev_start:n_data]
    fiber_end = ev_start
    count = 0
    for bfs in df3:
        if bfs < max(max_bfs,bfs_high)  and bfs > min(min_bfs, bfs_low):
            ev_end += 1
        else:
            count += 1
#            print(count, end='r')
            if count == 3:
                fiber_end = ev_end
#                print("fiberend:", fiber_end)
                break
 
#            peak_index, _ = find_peaks(df2.iloc[ev_start, ev_end], prominence=20) #, distance = 1000)            
            
#            data[colname[1]].iloc[ev_start] = min_bfs 
#    df3 = data1['bfs0'].iloc[ev_end-n_interval:ev_end]

#    ev_end = ev_start  
    ev_start = ev_end - int(int(n_data * 0.01)) 

    ## Validation 
    print("Check nominal data (sv_start+10:int(n_data *0.6) vs (fiber_start:fiber_end) :")
    df3 = data.iloc[sv_start:ev_end]
    print(df2.describe(), df3.describe())

    return sv_start, sv_end, ev_start, ev_end, fiber_end

"""
peak_index, _ = find_peaks(df3, threshold= bfs_high)
vally_index, _ = find_peaks(-df3, threshold= -bfs_high)
    peak_index
#peak_index, _ = find_peaks(y, prominence=2, threshold= y.max() / 10, distance=40)
#peak_index, _ = find_peaks(y, prominence=2)
#peak_index, _ = find_peaks(y, threshold= y.max() / 10)
#peak_index, _ = find_peaks(y, distance=5)
#peak_index, _ = find_peaks(y, prominence=10, distance=10)
#peak_index, _ = find_peaks(y, prominence=1.5, distance = 1000)
    peak_index, _ = find_peaks(data, prominence=20) #, distance = 1000)
    vally_index, _ = find_peaks(-data, prominence=20) #, distance = 1000)
#peak_index, _ = find_peaks(y, distance=100)

"""
class VerticalNavigationToolbar2Tk(NavigationToolbar2Tk):
   def __init__(self, canvas, window):
      super().__init__(canvas, window, pack_toolbar=False)

   # override _Button() to re-pack the toolbar button in vertical direction
   def _Button(self, text, image_file, toggle, command):
      b = super()._Button(text, image_file, toggle, command)
      b.pack(side=tk.TOP) # re-pack button in vertical direction
      return b

   # override _Spacer() to create vertical separator
   def _Spacer(self):
      s = tk.Frame(self, width=26, relief=tk.RIDGE, bg="DarkGray", padx=2)
      s.pack(side=tk.TOP, pady=5) # pack in vertical direction
      return s

   # disable showing mouse position in toolbar
   def set_message(self, s):
      pass

class Result_window:
    result_window_count = 0
    result_frame_count = 0

    def __init__(self, top=None):
        '''This class configures and populates the result window.
           top is the toplevel containing window.'''

        _bgcolor = '#d9d9d9'  # X11 color: 'gray85'
        _fgcolor = '#000000'  # X11 color: 'black'
        _compcolor = '#d9d9d9' # X11 color: 'gray85'
        _ana1color = '#d9d9d9' # X11 color: 'gray85'
        _ana2color = '#ececec' # Closest X11 color: 'gray92'
        self.style = ttk.Style()
        if sys.platform == "win32":
            self.style.theme_use('winnative')
        self.style.configure('.',background=_bgcolor)
        self.style.configure('.',foreground=_fgcolor)
        self.style.configure('.',font="TkDefaultFont")
        self.style.map('.',background=[('selected', _compcolor), ('active',_ana2color)])

        Result_window.result_window_count += 1

        if top == None:
            top = tk.Toplevel()
            self.top = top
        else:
            self.top = top

        top.geometry("1000x700+100+100")
        top.minsize(140, 1)
        top.maxsize(2000, 1400)
        top.resizable(1,  1)
        top.title("Free Strain Evaluation Results")
        top.configure(background="#d9d9d9")
        top.configure(highlightbackground="#d9d9d9")
        top.configure(highlightcolor="black")


        nb = ttk.Notebook(self.top)
        self.nb = nb
        self.nb.place(relx=0.01, rely=0.01, relheight=0.98, relwidth=0.98)
        self.nb.configure(takefocus="")
        self.InfoTable = []
        self.line = []
        self.dragmark = []
        self.datarange = []
        self.axislimit = []
        self.line_num=-1
        self.state = 'normal' # 'normal' 

#        self.nb_f1, self.fig_mov, self.mcanvas, self.toolbarm, self.axms1, self.axms2 
#  self.create_frametab(self, count=0, tabname="0")

    def Result_window_reflash(self):
        self.line_num -= 1
        try:
            self.axms1.clear()
            self.axms2.clear()
            self.fig_mov.clf()
        except:
            print("Info: axms1, axms2 clear error")            

        try:
            self.mcanvas.draw()
#            mov_win.mcanvas.flush_events()
            self.toolbarm.update()                
        except:
            print("Info: Canvas draw, toolbar update error")

        try:
            self.fig_mov.close()
        except:
            print("Info: Figure closing error")

        try:    
            tabs = self.nb.tabs()
            for tab in tabs:
                self.nb.forget(tab)  
        except:
            print("Info: tab forget error")


    def create_frametab(self, count=0, tabname=None):
        
        self.nb_f1 = tk.Frame(self.nb)
        self.nb.add(self.nb_f1, padding=2)
#                nb_txt = sensorname+'_'+str(plot_count)
#                nb_txt = str(plot_count)
        self.nb.tab(count, text=tabname, compound="left",underline='''-1''', )
        print('tframe tab: ok', count, tabname)
        self.nb_f1.configure(background="#d9d9d9")
        self.nb_f1.configure(highlightbackground="#d9d9d9")
        self.nb_f1.configure(highlightcolor="black")
        print('frame: ok', self.nb_f1)

        self.fig_mov = plt.figure(figsize=(10,6), dpi=100, label="Data Analysis")
        print("mov_win.fig_mov: ", self.fig_mov)              
        self.fig_mov.tight_layout()

        self.mcanvas = FigureCanvasTkAgg(self.fig_mov, master=self.nb_f1)
        self.mcanvas.draw()
        self.mcanvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH,expand=True)
        print('m cavas: ok', self.mcanvas)
        self.toolbarm = NavigationToolbar2Tk(self.mcanvas, self.nb_f1, pack_toolbar=True)
        self.toolbarm.update()
        self.toolbarm.pack(side=tk.BOTTOM, fill=tk.Y, anchor=tk.S)
        print('m toolbar: ok', self.toolbarm)
#                mov_win.mcanvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH,expand=True)
        print("Info: New canvas in new tab is created in result window")
 
        self.axms1 = self.fig_mov.add_subplot(111) ## axes 생성                
        self.axms2 = self.axms1.twinx() 
        Result_window.result_frame_count += 1
        return self.nb_f1, self.fig_mov, self.mcanvas, self.toolbarm, self.axms1, self.axms2

    def delete_frametab(self, count=0, tabname=None):
        self.fig_mov.clf()
#        self.axms1 = self.fig_mov.add_subplot(111) ## axes 생성                
#        self.axms2 = self.axms1.twinx() 
#        self.fig_mov = plt.figure(figsize=(4,2), dpi=100, label="BFS standard deviation")
        self.mcanvas.draw()
        self.toolbarm.update()
        self.forget(tabname)
        self.nb_f1.destroy()
#        self.nb_f1 = tk.Frame(self.nb)
#        self.nb.add(self.nb_f1, padding=2)
#                nb_txt = sensorname+'_'+str(plot_count)
#                nb_txt = str(plot_count)
#        self.nb.tab(count, text=tabname, compound="left",underline='''-1''', )
        print('frame: ok', self.nb_f1)
        Result_window.result_frame_count -= 1

    def Result_window_close(self):
        Result_window.result_window_count -= 1
#        Result_window.result_frame_count = 0
        try:
            self.fig_mov.close()
        except:
            print("Info: figure close error")            

        try:
            self.mcanvas.draw()
#            mov_win.mcanvas.flush_events()
            self.toolbarm.update()                
        except:
            print("Info: Canvas draw, toolbar update error")

        try:    
            tabs = self.nb.tabs()
            for tab in tabs:
                self.nb.forget(tab)  
        except:
            print("Info: tab forget error")

        self.top.destroy()

class DraggableMarker():
    def __init__(self, ax=None, lines=None):
        if ax == None:
            self.fig = plt.gcf()
            self.ax = plt.gca()
            print("gcf, gca", self.fig, self.ax)
        else:
            self.ax=ax
        if lines==None:
            self.lines=self.ax.lines
        else:
            self.lines=lines
        self.lines = self.lines[:]
        self.selectline_index = 0
#        line = self.lines[self.selectline_index]
#        x,y = line.get_data()
        initial_loc = [l.get_data() for l in self.lines] 
#        print(len(initial_loc), len(initial_loc[0]))
#        print(initial_loc)

        self.tx =  [self.ax.text(initial_loc[i][0][0], initial_loc[i][1][0], "") for i, l in enumerate(self.lines)]
        self.marker = [self.ax.plot([initial_loc[i][0][0]], [initial_loc[i][1][0]], marker="o", color="red")[0]  for i, l in enumerate(self.lines)]    

#        self.tx =  [self.ax.text(l.get_data()[0], l.get_data()[1], "") for l in self.lines]
#        self.marker = [self.ax.plot([0],[0], marker="o", color="red")[0]  for l in self.lines]    

        self.draggable=False
        self.connect()

    def connect(self):
        self.cidkey = self.ax.figure.canvas.mpl_connect("key_press_event", self.keypress)
        self.cidpress = self.ax.figure.canvas.mpl_connect("button_press_event", self.click)
        self.cidrelease = self.ax.figure.canvas.mpl_connect("button_release_event", self.release)
        self.cidmotion = self.ax.figure.canvas.mpl_connect("motion_notify_event", self.drag)

    def keypress(self, event):
        print("Key press: ", event.key)
        if event.key == "w":    #Draggable mode - switch line
            self.draggable=True
            self.selectline_index += 1 
        elif event.key == "e":  #Draggable mode - switch line
            self.draggable=True
            self.selectline_index += 1 
        elif event.key == "a":  #Draggable mode - add mark
            self.draggable=True
#            self.marking(event)
        elif event.key == "c":  #Draggable mode - clear mark
            self.draggable=False            
        else: 
            self.draggable=False            

        self.ax.figure.canvas.draw_idle()

    def click(self, event):
        if event.button==1:     #leftclick
            self.draggable=True
            self.update(event)
        elif event.button==3:   #rightclick
            self.draggable=True
            self.marking(event)
        [tx.set_visible(self.draggable) for tx in self.tx]
        [m.set_visible(self.draggable) for m in self.marker]
        self.ax.figure.canvas.draw_idle()

    def drag(self, event):
        if self.draggable:
            print("drag mode is disabled", end="\r")            
#            self.update(event)
#            self.ax.figure.canvas.draw_idle()

    def release(self, event):
        self.draggable=False

    def marking(self,event):
        no_line = len(self.lines)
        selectline = self.selectline_index % no_line
        line = self.lines[selectline]
        if self.draggable:
            x,y = self.get_closest(line, event.xdata)
            self.tx[selectline].set_position((x,y))
            self.tx[selectline].set_text("x:{}\ny:{}".format(x,y))
            self.marker[selectline].set_data([x],[y])
            clipboard.copy(x)
            print("Copy x Value to clipboard: ", x)            

    def update(self, event):
        no_line = len(self.lines)
        selectline = self.selectline_index % no_line
        line = self.lines[selectline]
        print("update:", selectline, line)
        if self.draggable:
            x,y = self.get_closest(line, event.xdata)
            self.tx[selectline].set_position((x,y))
            self.tx[selectline].set_text("x:{}\ny:{}".format(x,y))
            self.marker[selectline].set_data([x],[y])
            print("Value: ", x, y)        

        """
        for i, line in enumerate(self.lines):
            print("update:", i, line)
            x,y = self.get_closest(line, event.xdata)
            self.tx[i].set_position((x,y))
            self.tx[i].set_text("x:{}\ny:{}".format(x,y))
            self.marker[i].set_data([x],[y])
        """
    def get_closest(self,line, mx):
        x,y = line.get_data()
        mini = np.argmin(np.abs(x-mx))
        return x[mini], y[mini]

    def disconnect(self):
        self.point.figure.canvas.mpl_disconnect(self.cidpress)
        self.point.figure.canvas.mpl_disconnect(self.cidrelease)
        self.point.figure.canvas.mpl_disconnect(self.cidmotion)

"""
    def refreshFigure(self, x, y):
        self.lines.set_data(x, y)
        self.ax.set_xlim(x.min(), x.max())
        self.ax.set_ylim(y,min(), y.max())
        self.canvas.draw()
"""

class Toggle():
    def __init__(self):
        self.all_visible = True
        self.opos = None

    def toggle(self,evt):
        if evt.inaxes:
            if self.all_visible:
                for ax in fig.axes:
                    if ax != evt.inaxes:
                        ax.set_visible(False)
                self.opos = evt.inaxes.get_position()
                evt.inaxes.set_position(gs[0].get_position(fig))
                self.all_visible=False
            else:
                for ax in fig.axes:
                    ax.set_visible(True)

                evt.inaxes.set_position(self.opos)
                self.all_visible = True
                self.opos = None
            self.fig.canvas.draw_idle()




class PDF(FPDF):
    def __init__(self):
        super().__init__()
        self.WIDTH = 210
        self.HEIGHT = 297
        
    def header(self):
        # Custom logo and positioning
        # Create an `assets` folder and put any wide and short image inside
        # Name the image `logo.png`
#        self.image('LSCNS_Logo.png', 10, 8, 33)
        self.set_font('Arial', 'B', 11)
        self.cell(self.WIDTH - 80)
        self.cell(60, 1, 'Sales report', 0, 0, 'R')
        self.ln(20)
        
    def footer(self):
        # Page numbers in the footer
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.set_text_color(128)
        self.cell(0, 10, 'Page ' + str(self.page_no()), 0, 0, 'C')

    def page_body(self, images):
        # Determine how many plots there are per page and set positions
        # and margins accordingly
        if len(images) == 3:
            self.image(images[0], 15, 25, self.WIDTH - 30)
            self.image(images[1], 15, self.WIDTH / 2 + 5, self.WIDTH - 30)
            self.image(images[2], 15, self.WIDTH / 2 + 90, self.WIDTH - 30)
        elif len(images) == 2:
            self.image(images[0], 15, 25, self.WIDTH - 30)
            self.image(images[1], 15, self.WIDTH / 2 + 5, self.WIDTH - 30)
        else:
            self.image(images[0], 15, 25, self.WIDTH - 30)
            
    def print_page(self, images):
        # Generates the report
        self.add_page()
        self.page_body(images)


